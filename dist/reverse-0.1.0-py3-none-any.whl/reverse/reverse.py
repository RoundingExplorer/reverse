def reverse(a: int) -> int:
    num = a
    
    return(str(num)[::-1])
